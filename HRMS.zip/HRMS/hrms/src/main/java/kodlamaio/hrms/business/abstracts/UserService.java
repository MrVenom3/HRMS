package kodlamaio.hrms.business.abstracts;

public interface UserService {

}
