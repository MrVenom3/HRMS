package kodlamaio.hrms.business.concretes;

import kodlamaio.hrms.business.abstracts.UserService;

public class UserManager implements UserService{

}
