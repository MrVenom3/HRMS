package kodlamaio.hrms.business.concretes;

import kodlamaio.hrms.business.abstracts.SystemUserService;

public class SystemUserManager implements SystemUserService {

}
